import unittest
import random


ARRAY_RANGE = (-1000, 1000)
INT_RANGE = (0, 100)

def show(self):
    a = random.randint(*INT_RANGE)
    print(a)

