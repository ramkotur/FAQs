
a="Ram"
b=100

print (f"%s = %s"%(a,b))

print(f"{a}, {b}")