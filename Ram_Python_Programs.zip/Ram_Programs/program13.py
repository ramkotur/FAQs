# ----------- List -------------
a=[10,20,30,40,50]
a[2]=100
a.append(200)
print(a)

# -----------Tuple---------------
# Immutable: Once a tuple is created, you cannot change, add, or remove elements.
# Syntax: Defined using parentheses ().
# Performance: Faster than lists due to the immutability.

x =(10,20,30,40)
print(x)
