
# def show(a,b):
#     return a+b
# print (show(10,2))
#
# def show1(a,b) -> int:
#     return a+b
# print(show1(1,2))
#

# rng = range(1,10)
# for i in rng:
#     print(i)
# print(list(rng))

# for i in range(1,10,2):
#     print(i)

#------------ Map Function ------------

# strings = ["my","aa","bb","cc"]
# l = map(len,strings)
# print(list(l))

#--------------lambda function ------------
# l = map(lambda  x: x+"s",strings)
# print(list(l))

# -----------------------
strings = ["my","aa","bb","ccc"]
l = filter(lambda x: len(x) > 2,strings)
print (list(l))

