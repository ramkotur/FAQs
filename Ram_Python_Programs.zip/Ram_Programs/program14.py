
def show() -> int:
    return  10
print (show())

for a in range(2,10):
    print(a)
