import unittest

class program1(unittest.TestCase):
    def show(self, N):
        print(N)

if __name__ == "__main__":
    unittest.main()
        